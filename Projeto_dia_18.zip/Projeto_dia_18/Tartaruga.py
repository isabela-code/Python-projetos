import turtle
import random

class Tartaruga:

    def __init__(self):
        self.y = 0
    def desenho(self):
        lista_cores = ['blue', 'red', 'yellow', 'black', 'purple', 'pink', 'green', 'orange', 'brown']
        sakura = turtle.Turtle()
        sakura.pen(shown=False)
        sakura.penup()
        sakura.setx(-250)
        sakura.sety(-150 + self.y)
        for i in range(0, 11):
            escolha = random.choice(lista_cores)
            sakura.dot(20, escolha)
            sakura.forward(50)
        self.y += 50

