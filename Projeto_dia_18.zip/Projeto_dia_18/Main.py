from Tartaruga import Tartaruga
import turtle

tela = turtle.Screen()
Sakura = Tartaruga()
for i in range (0,9):
    Sakura.desenho()
tela.exitonclick()