import pygame

largura, altura = 800,800
Linhas,Colunas = 8,8
Tamanho = largura//Colunas

laranja = (255,165,0)
branco = (255,255,255)
cinza = (50,50,50)
preto = (0,0,0)

MARROM = "#070001"
BEGE = "#dfba69"
BRANCO = "#b3a176"
CINZA = "#d6c396"
CINZA_ESCURO =  "#83764c"
LARANJA = "#a7321c"

UFG = pygame.transform.scale(pygame.image.load("../Imagem/Marca_na_Horizontal_capa_ufg.jpg"), (44, 25))