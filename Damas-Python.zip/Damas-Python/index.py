#!python3

from Damas import myDamas

myDamas()