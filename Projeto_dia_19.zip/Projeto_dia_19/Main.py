from Tartaruga import Tartaruga
from tkinter import simpledialog

Sakura = Tartaruga()
Sakura.inicio()

while True:
    nome_tartaruga = simpledialog.askstring("Aposta", "Qual tartaruga você quer apostar? (preta/rosa/verde/laranja/azul)")
    if nome_tartaruga:
        while True:
            Sakura.corrida()
            if Sakura.vencedor(nome_tartaruga):
                break