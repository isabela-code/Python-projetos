import turtle
import random
from tkinter import simpledialog
from tkinter import messagebox

class Tartaruga:
    def __init__(self):
        self.x = -460
        self.y = 0
        self.cont0 = 0
        self.cont1 = 0
        self.cont2 = 0
        self.cont3 = 0
        self.cont4 = 0

    def inicio(self):#criando as tartarugas e as cores
        self.sakura0 = turtle.Turtle()
        self.sakura0.shape('turtle')
        self.sakura0.penup()
        self.sakura0.color('black')
        self.sakura0.setx(self.x)
        self.sakura0.sety(-100 + self.y)
        self.y += 50
        self.sakura0.pendown()

        self.sakura1 = turtle.Turtle()
        self.sakura1.shape('turtle')
        self.sakura1.penup()
        self.sakura1.color('pink')
        self.sakura1.setx(self.x)
        self.sakura1.sety(-100 + self.y)
        self.y += 50
        self.sakura1.pendown()

        self.sakura2 = turtle.Turtle()
        self.sakura2.shape('turtle')
        self.sakura2.penup()
        self.sakura2.color('green')
        self.sakura2.setx(self.x)
        self.sakura2.sety(-100 + self.y)
        self.y += 50
        self.sakura2.pendown()

        self.sakura3 = turtle.Turtle()
        self.sakura3.shape('turtle')
        self.sakura3.penup()
        self.sakura3.color('orange')
        self.sakura3.setx(self.x)
        self.sakura3.sety(-100 + self.y)
        self.y += 50
        self.sakura3.pendown()

        self.sakura4 = turtle.Turtle()
        self.sakura4.shape('turtle')
        self.sakura4.penup()
        self.sakura4.color('blue')
        self.sakura4.setx(self.x)
        self.sakura4.sety(-100 + self.y)
        self.y += 50
        self.sakura4.pendown()

        self.bandeira0 = turtle.Turtle()
        self.bandeira0.shape('arrow')
        self.bandeira0.color('black')
        self.bandeira0.penup()
        self.bandeira0.setx(430)
        self.bandeira0.sety(-310 - self.x)
        self.y += 50
        self.bandeira0.pendown()
        self.bandeira0.stamp()

        self.bandeira1 = turtle.Turtle()
        self.bandeira1.shape('arrow')
        self.bandeira1.color('black')
        self.bandeira1.penup()
        self.bandeira1.setx(430)
        self.bandeira1.sety(310 +self.x)
        self.y += 50
        self.bandeira1.pendown()
        self.bandeira1.stamp()
    def corrida(self):
        velocidade = [1,2,3,4,5,6,7,8,9]
        escolha = random.choice(velocidade)
        self.sakura0.penup()
        self.sakura0.speed(50000)
        self.sakura0.forward(escolha)
        self.sakura0.pendown()
        self.cont0 += escolha

        escolha = random.choice(velocidade)
        self.sakura1.penup()
        self.sakura1.speed(50000)
        self.sakura1.forward(escolha)
        self.sakura1.pendown()
        self.cont1 += escolha

        escolha = random.choice(velocidade)
        self.sakura2.penup()
        self.sakura2.speed(50000)
        self.sakura2.forward(escolha)
        self.sakura2.pendown()
        self.cont2 += escolha

        escolha = random.choice(velocidade)
        self.sakura3.penup()
        self.sakura3.speed(50000)
        self.sakura3.forward(escolha)
        self.sakura3.pendown()
        self.cont3 += escolha

        escolha = random.choice(velocidade)
        self.sakura4.penup()
        self.sakura4.speed(50000)
        self.sakura4.forward(escolha)
        self.sakura4.pendown()
        self.cont4 += escolha

    def vencedor(self, nome_tartaruga):
        tela = turtle.Screen()
        mensagem = ""

        if self.cont0 >= 890:
            mensagem = "O vencedor é a tartaruga preta"
            if nome_tartaruga == 'preta':
                mensagem += "\nVocê ganhou a corrida, seu prêmio é 1 milhão de reais, parabéns"
            if nome_tartaruga != 'preta':
                mensagem += "\nVocê perdeu a corrida, deposite 1 milhão de reais na minha conta"
            tela.bye()
        elif self.cont1 >= 890:
            mensagem = "O vencedor é a tartaruga rosa"
            if nome_tartaruga == 'rosa':
                mensagem += "\nVocê ganhou a corrida, seu prêmio é 1 milhão de reais, parabéns"
            if nome_tartaruga != 'rosa':
                mensagem += "\nVocê perdeu a corrida, deposite 1 milhão de reais na minha conta"
            tela.bye()
        elif self.cont2 >= 890:
            mensagem = "O vencedor é a tartaruga verde"
            if nome_tartaruga == 'verde':
                mensagem += "\nVocê ganhou a corrida, seu prêmio é 1 milhão de reais, parabéns"
            if nome_tartaruga != 'verde':
                mensagem += "\nVocê perdeu a corrida, deposite 1 milhão de reais na minha conta"
            tela.bye()
        elif self.cont3 >= 890:
            mensagem = "O vencedor é a tartaruga laranja"
            if nome_tartaruga == 'laranja':
                mensagem += "\nVocê ganhou a corrida, seu prêmio é 1 milhão de reais, parabéns"
            if nome_tartaruga != 'laranja':
                mensagem += "\nVocê perdeu a corrida, deposite 1 milhão de reais na minha conta"
            tela.bye()
        elif self.cont4 >= 890:
            mensagem = "O vencedor é a tartaruga azul"
            if nome_tartaruga == 'azul':
                mensagem += "\nVocê ganhou a corrida, seu prêmio é 1 milhão de reais, parabéns"
            if nome_tartaruga != 'azul':
                mensagem += "\nVocê perdeu a corrida, deposite 1 milhão de reais na minha conta"
            tela.bye()

        if mensagem:
            messagebox.showinfo("Ganhador", mensagem)
        else:
            return False

    def fazer_aposta(self):
        nome_tartaruga = simpledialog.askstring("Aposta",
                                                "Qual tartaruga você quer apostar? (preta/rosa/verde/laranja/azul)")
        if nome_tartaruga:
            self.corrida()

