import random

z = 1
soma = 0 
mãoj = []
mãoc = []

cartas = ['11','10','10','10','10','9','8','7','6','5','4','3','2','1']
escolhaj =random.choices(cartas,k=2)
escolhac = random.choices(cartas,k=2)
for s in escolhaj:
    mãoj.append(s)
for s in mãoj:
    soma += int(s)
for i in cartas:
    for s in mãoj:
        if i == s:
            cartas.remove(i)
somac = 0
for i in escolhac:
    mãoc.append(i)
for i in escolhac:
    somac += int(i)
for i in cartas:
    for s in mãoc:
        if i == s:
            cartas.remove(i)

if soma >= 22 or somac == 21:
    print(f'Mal começou o jogo e você ja perdeu, a soma das suas cartas era {soma}')
    print(f'A sua soma de cartas do seu oponente era {somac}')
    z = -1
if somac >= 22 or soma == 21:
    print(f'Parabens, mal começou o jogo e você ja ganhou')
    print(f'A sua soma de cartas era {soma} e a do seu oponente era {somac}')
    z = -1

while z > 0:
    print(f'A soma das suas cartas é {soma}, deseja pegar mais uma carta do monte ou parar: ')
    resp = input('')
    if resp == 'monte':
        escolhaj = random.choices(cartas,k=1)
        escolhac = random.choices(cartas,k=1)
        for s in escolhaj:
            mãoj.append(s)
        for s in escolhaj:
            soma += int(s)
        for i in cartas:
            for s in mãoj:
                if i == s:
                    cartas.remove(i)
        for i in escolhac:
            mãoc.append(i)
        for i in escolhac:
            somac += int(i)
        for i in cartas:
            for s in mãoj:
                if i == s:
                    cartas.remove(i)
        print(f'Agora sua soma de cartas é {soma}')
        if soma >= 22:
            print('Você estorou')
            z = - 1
        elif somac >= 22 :
            print('Parabens, você ganhou')
            print('Seu oponente estorou')
        elif soma == 21 and somac != 21:
            print('Parabens você ganhou')
            print(f'A soma das cartas do seu oponente era {somac}')
            z = -1
        elif soma == somac:
            print('Deu empate')
            print(f'A soma das cartas do seu oponente era {somac}')
            escolhaj = random.choices(cartas,k=1)
            escolhac = random.choices(cartas,k=1)
            print('Vence quem tirar a maior carta')
            print(escolhaj)
            print(escolhac)
            if escolhaj > escolhac:
                print('Parabens, você ganhou')
            else: 
                print('Mais sorte da proxima vez, você perdeu')
            z = -1
    else:
        print(f'A soma das suas cartas é {soma}')
        if soma > somac:
            print('Parabens você ganhou')
            print(f'A soma das cartas do seu oponente era {somac}')
        elif soma < somac:
            print('Você perdeu')
            print(f'A soma das cartas do seu oponente era {somac}')
        elif soma >= 22 or somac == 21:
            print(f'Você perdeu, a soma das suas cartas era {soma}')
            print(f'A sua soma de cartas do seu oponente era {somac}')
        elif somac >= 22 or soma == 21:
            print(f'Parabens,você ganhou')
            print(f'A sua soma de cartas era {soma} e a do seu oponente era {somac}')
        elif soma==somac:
            print('Deu empate')
            print(f'A soma das cartas do seu oponente era {somac}')
            escolhaj = random.choices(cartas,k=1)
            escolhac = random.choices(cartas,k=1)
            print('Vence quem tirar a maior carta')
            print(escolhaj)
            print(escolhac)
            if escolhaj > escolhac:
                print('Parabens, você ganhou')
            else: 
                print('Mais sorte da proxima vez, você perdeu')
        elif somac >= 22 and soma < 21:
            print(f'Parabens,você ganhou')
            print(f'A sua soma de cartas era {soma} e a do seu oponente era {somac}')
            print('Seu oponente estorou')
        elif soma >= 22 and somac < 21:
            print(f'Você perdeu')
            print(f'A sua soma de cartas era {soma} e a do seu oponente era {somac}')
            print('Você estorou')
        z = -1