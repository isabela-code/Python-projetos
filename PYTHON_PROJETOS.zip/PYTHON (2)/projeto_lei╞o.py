print('Bem vindo ao leilão supremo')
x = input('Digite seu nome: ')
y = float(input('Digite a quantia que você ira usar: R$ '))
nomes = []
valores = []
for i in range(0, 1):
    nomes.append(x)
    for l in range(0, 1):
        valores.append(y)
while x != 'não':
    x = input(
        'Mais alguem ira participar do leilão? Se sim, digite o nome. Se não, digite *não*: ')
    if x == 'não':
        print()
    else:
        y = float(input('Digite o valor que essa pessoa ira usar: R$ '))
        for i in range(0, 1):
            nomes.append(x)
            for l in range(0, 1):
                valores.append(y)
posi = valores[0]
z = len(valores)
k = 0
for i in range(0, z):
    if posi < valores[i]:
        maior = valores[i]
        k += 1
    else:
        maior = valores[0]
for i in nomes:
    vencedor = nomes[k]
print(f'O vencedor do leilão supremo é {vencedor}, com o lance de R$ {maior}')
