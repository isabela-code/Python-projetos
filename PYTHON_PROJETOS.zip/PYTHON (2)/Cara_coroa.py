import random 

cara_coroa = random.randint(0,1)

if cara_coroa == 0:
    print("CARA")
else :
    print("COROA")