desenho = '''
    {   }  {
    }_{ __{
 .-{   }   }-.
(   }     {   )
|`-.._____..-'|
|             ;--.
|            (__  )
|             | )  )
|             |/  /
|             /  /  
|            (  /
\             y'
  `-.._____..-' 
'''
print('Bem vindo a cafeteria zobinha')
vezes = int(input('Quantas bebidas você vai querer: '))
leite = 200
agua = 300
cafe = 100
expresso = 1.50
latte = 2.50
cappuccino = 3.50
def preço():
    global expresso
    global latte
    global cappuccino
    if x == 'expresso':
        print(f'O valor da sua bebida é de R$ {expresso}')
    elif x == 'latte':
        print(f'O valor da sua bebida é de R$ {latte}')
    elif x == 'cappuccino':
        print(f'O valor da sua bebida é de R$ {cappuccino}')
    def moedas():
        global expresso
        global latte
        global cappuccino
        global cafe 
        y = int(input('Quantas moedas de R$ 0.05 você ira colocar na maquina: '))
        z = int(input('Quantas moedas de R$ 0.10 você ira colocar na maquina: '))
        w = int(input('Quantas moedas de R$ 0.25 você ira colocar na maquina: '))
        f = int(input('Quantas moedas de R$ 0.50 você ira colocar na maquina: '))
        u = int(input('Quantas moedas de R$ 1.00 você ira colocar na maquina: '))
        soma = (0.05 * y) + (0.10 * z) + (0.25 * w) + (0.50 * f) + (1 * u)
        print(f'Você colocou R$ {soma}')
        if expresso > soma:
            print('Parece que você não tem dinheiro o suficiente')
        elif latte > soma:
            print('Parece que você não tem dinheiro o suficiente')
        elif cappuccino > soma:
            print('Parece que você não tem dinheiro o suficiente')
        if soma > expresso and x == 'expresso':
            troco = soma - expresso
            print(f"Seu troco é de {troco}")
        elif soma > latte and x == 'latte':
            troco = soma - latte
            print(f"Seu troco é de {troco}")
        elif soma > cappuccino and x == 'cappuccino':
            troco = soma - cappuccino
            print(f"Seu troco é de {troco}")
    return moedas()
def quantidade():
    global leite
    global agua
    global cafe
    if x == 'relatorio':
        print(f'Tem {leite} ml de leite')
        print(f'Tem {agua} ml de agua')
        print(f'Tem {cafe} g de cafe')
def checar():
    if agua < 50:
        print('Infelizmente não temos estoque para nenhum dos cafes')
        vezes = 0
    elif agua < 200:
        print('Infelizmente a bebida latte e cappuccino saiu do estoque por hoje')
while vezes > 0:
    x = input('Temos expresso, latte e cappuccino. Qual desses três você deseja beber: ')
    if x == 'expresso' and agua > 50:
        leite -= 0
        agua -= 50
        cafe -= 18
    elif x == 'latte' and agua > 200:
        leite -= 150
        agua -= 200
        cafe -= 24
    elif x == 'cappuccino' and agua > 250:
        leite -= 100
        agua -= 250
        cafe -= 24
    if x == 'relatorio':
        vezes += 1
        quantidade()
    else:
        preço()
        checar()
        print('Aqui esta sua bebida')
        print(desenho)
    vezes -= 1
print('Obrigado por comprar na cafeteria zobinha')