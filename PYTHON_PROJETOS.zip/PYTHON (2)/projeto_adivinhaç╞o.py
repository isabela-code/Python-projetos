import random

print('Bem vindo ao jogo de adivinhação')
print('As dificuldades do jogo são')
print('Facil')
print('Medio')
print('Dificil')
y = input('Escolha a dificuldade do jogo: ')

if y == 'facil':
    chances = 15
elif y == 'medio':
    chances = 10 
else: 
    chances = 5

print(f'Dificuldade escolhida foi {y}, você tem {chances} chances')
j = int(input('Escolha um numero entre 0 e 100: '))
def escolha():
    x = random.randrange(0,100)
    return x
final = escolha()

while chances > 0:
    if final == j and chances!= 0:
        print('MEU DEUS, você conseguiu adivinhar o numero secreto')
        chances = -1
    elif final > j and chances != 0:
        print('O numero que você escolheu é muito pequeno, tente outro numero')
        chances -= 1
    elif final < j and chances != 0:
        print('O numero que você escolheu é muito grande, tente outro numero')
        chances -= 1
    if chances > 0:
        print(f'Você tem {chances} chances')
        j = int(input('Escolha um numero entre 0 e 100: '))
print()
print(f'O numero secreto era {final}')