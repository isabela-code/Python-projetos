print('Bem vindo a calculadora!')
x = int(input('Digite o primeiro numero da sua conta: '))
y = int(input('Digite o segundo numero da sua conta: '))
z = 1

def soma1(x,y):
    return x + y
def sub1(x,y):
    return x - y
def mult1(x,y):
    return x * y
def div1(x,y):
    return x/y

def soma2(c,y):
    return c + y
def sub2(c,y):
    return c - y
def mult2(c,y):
    return c * y
def div2(c,y):
    return c / y

print('Seleciona qual sera a operação: ')
print('+')
print('-')
print('*')
print('/')
fator = input('')
if fator == '+':
    c = soma1(x,y)
    print(soma1(x,y))
elif fator == '-':
    c = sub1(x,y)
    print(sub1(x,y))
elif fator == '*':
    c = mult1(x,y)
    print(mult1(x,y))
else:
    c = div1(x,y)
    print(div1(x,y))

while z >= 0:
    print('Caso você deseje uma nova operação com o resultado da primeira conta digite *1*, caso queira uma nova operação com novos numeros digite *2* ou se quer finalizar o programa digite qualquer outro numero')
    z = int(input(''))
    if z == 1:
        y = int(input('Digite o segundo numero da sua conta: '))
        print('Seleciona qual sera a operação: ')
        print('+')
        print('-')
        print('*')
        print('/')
        fator = input('')
        if fator == '+':
            print(soma2(c,y))
        elif fator == '-':
            print(sub2(c,y))
        elif fator == '*':
            print(mult2(c,y))
        else:
            print(div2(c,y))
    elif z == 2:
        x = int(input('Digite o primeiro numero da sua conta: '))
        y = int(input('Digite o segundo numero da sua conta: '))
        print('Seleciona qual sera a operação: ')
        print('+')
        print('-')
        print('*')
        print('/')
        fator = input('')
        if fator == '+':
            print(soma1(x,y))
        elif fator == '-':
            print(sub1(x,y))
        elif fator == '*':
            print(mult1(x,y))
        else:
            print(div1(x,y))
    else:
        print('Obrigado por usar a nossa calculadora')
        z = -1
