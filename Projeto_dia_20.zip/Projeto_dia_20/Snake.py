# Arquivo: Snake.py
import turtle
import random

class Snake:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.comida = turtle.Turtle(shape='circle')
        self.comida.penup()
        turtle.tracer(0)
    def corpo(self):
        corpo = turtle.Turtle(shape='square')
        corpo.color('red')
        corpo.penup()
        self.x = 0
        self.y = 0
    def comida_pos(self):
        x = self.coordenadas_x()
        y = self.coordenadas_y()
        self.comida.setpos(x, y)
        turtle.update()
    def coordenadas_x(self):
        self.x = random.randint(-460, 460)
        return self.x
    def coordenadas_y(self):
        self.y = random.randint(-400, 400)
        return self.y
    def atualiza_comida(self):
        self.comida_pos()
        turtle.ontimer(self.atualiza_comida, t=10000)
