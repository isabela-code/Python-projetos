# Arquivo: main.py
from Snake import Snake
import turtle

tela = turtle.Screen()
Corpo = Snake()
Corpo.corpo()
Corpo.comida_pos()
Corpo.atualiza_comida()
tela.exitonclick()
