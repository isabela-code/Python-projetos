from Quiz import Quiz

quiz = Quiz()
quiz.perguntas()