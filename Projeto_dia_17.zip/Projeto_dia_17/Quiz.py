class Quiz:

    def __init__(self):
        self.pontuação = 0
    def perguntas(self):
        i = 1
        while i < 11:
            print(f'Questão {i}')
            print('É verdade que as cores do arco-íris são Vermelho, Laranja, Amarelo, Verde e Azul?')
            resp = input()
            if resp == 'falso':
                self.pontuação += 1
            else:
                self. pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print(f'Questão {i}')
            print('É Verdade que o cantor Britânico Fred Mercury Pertenceu a banda de Rock "Queen"?')
            resp = input()
            if resp == 'verdadeiro':
                self.pontuação += 1
            else:
                self.pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print(f'Questão {i}')
            print('É verdade que o único país onde o animal coala vive é na Austrália?')
            resp = input()
            if resp == 'verdadeiro':
                self.pontuação += 1
            else:
                self.pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print(f'Questão {i}')
            print('É Incorreto afirmar que a Amazônia é a segunda maior floresta Tropical mais extensa do mundo?')
            resp = input()
            if resp == 'verdadeiro':
                self.pontuação += 1
            else:
                self.pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print(f'Questão {i}')
            print('É verdade que as lutas de Judô são disputadas no tatame?')
            resp = input()
            if resp == 'verdadeiro':
                self.pontuação += 1
            else:
                self.pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print(f'Questão {i}')
            print('Primogênito é o nome dado ao último filho de um casal?')
            resp = input()
            if resp == 'falso':
                self.pontuação += 1
            else:
                self.pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print(f'Questão {i}')
            print('É verdade que a cidade Brasileira conhecida como a terra da garoa é Curitiba?')
            resp = input()
            if resp == 'falso':
                self.pontuação += 1
            else:
                self.pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print(f'Questão {i}')
            print('É correto afirmar que um animal bípede contém duas patas?')
            resp = input()
            if resp == 'verdadeiro':
                self.pontuação += 1
            else:
                self.pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print(f'Questão {i}')
            print('É incorreto dizer que Lisboa é a capital de Portugal?')
            resp = input()
            if resp == 'falso':
                self.pontuação += 1
            else:
                self.pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print(f'Questão {i}')
            print('É incorreto dizer que um ano bissexto tem 366 dias?')
            resp = input()
            if resp == 'falso':
                self.pontuação += 1
            else:
                self.pontuação += 0
            print(f'Pontuação {self.pontuação}/{i}')
            i += 1
            print()
            print(f'Pontuação final {self.pontuação}/{i}')
